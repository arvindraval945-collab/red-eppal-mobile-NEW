# Red Eppal Mobile — Complete Bundle

This bundle contains everything needed to run, develop, and deploy the Red Eppal Mobile project.

Included:
- backend/ (Node.js + Postgres + Docker)
- admin/ (React + Vite starter)
- admin_full/ (Styled React admin)
- flutter/ (minimal starter)
- flutter_full/ (expanded 12-screen starter)
- website/ (static landing page)
- openapi.yaml
- docker-compose.yml
- invoices generator, Razorpay integration examples

## Quick local startup (Docker)
1. Edit `docker-compose.yml` to set `JWT_SECRET`, `DATABASE_URL`, `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`.
2. Run:
   ```
   docker-compose up --build
   ```
3. Admin UI:
   - `cd admin_full` or `cd admin`
   - `npm install`
   - `npm run dev`
4. Flutter:
   - `cd flutter_full`
   - `flutter pub get`
   - `flutter run`

## Git / GitHub push (example)
1. Initialize repo and push:
   ```
   git init
   git add .
   git commit -m "Initial commit - Red Eppal Mobile complete bundle"
   # create remote on GitHub via website or use gh CLI:
   gh repo create red-eppal-mobile --public --source=. --remote=origin --push
   # or if you have a remote URL:
   git remote add origin <REMOTE_URL>
   git branch -M main
   git push -u origin main
   ```

## Notes & Next Steps
- Change default admin password after first login (admin/admin123).
- Use managed Postgres in production.
- Configure SSL/HTTPS and environment secrets.
- Replace placeholder phone/address/logo in website and app.

If you want, I can:
- Create the GitHub repository for you and provide the `git` commands + remote URL (I will generate the commands here; you must run them), or
- Generate CI (GitHub Actions) for building backend Docker images and running tests, or
- Produce Play Store-ready AAB build instructions and shell scripts.

