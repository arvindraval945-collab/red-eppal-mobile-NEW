CREATE TABLE IF NOT EXISTS admins (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bookings (
  id TEXT PRIMARY KEY,
  name TEXT,
  phone TEXT,
  service TEXT,
  notes TEXT,
  status TEXT,
  created_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inventory (
  id SERIAL PRIMARY KEY,
  part_name TEXT,
  sku TEXT,
  qty INTEGER DEFAULT 0,
  purchase_price NUMERIC,
  sell_price NUMERIC
);

CREATE TABLE IF NOT EXISTS invoices (
  id SERIAL PRIMARY KEY,
  booking_id TEXT REFERENCES bookings(id),
  pdf_path TEXT,
  created_at TIMESTAMP DEFAULT now()
);
