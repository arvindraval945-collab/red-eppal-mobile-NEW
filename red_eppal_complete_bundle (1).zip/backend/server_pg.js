// server_pg.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const createInvoicePDF = require('./invoice_pdf');
const Razorpay = require('razorpay');

const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgres://postgres:password@localhost:5432/red_eppal' });
const SECRET = process.env.JWT_SECRET || 'dev_secret';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID || '',
  key_secret: process.env.RAZORPAY_KEY_SECRET || ''
});

async function runMigrations() {
  const sql = fs.readFileSync('./migrations_pg.sql','utf8');
  await pool.query(sql);
}

(async ()=>{
  try{
    await runMigrations();
    const r = await pool.query('SELECT count(*) FROM admins');
    if (r.rows[0].count === '0') {
      const pwHash = bcrypt.hashSync('admin123', 8);
      await pool.query('INSERT INTO admins (username,password_hash) VALUES ($1,$2)', ['admin', pwHash]);
      console.log('Created default admin admin/admin123');
    }
  } catch(e){
    console.error('Migration error', e);
  }
})();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// PUBLIC: create booking
app.post('/api/bookings', async (req,res)=>{
  const id = uuidv4().split('-')[0];
  const { name, phone, service, notes } = req.body;
  const now = new Date();
  await pool.query('INSERT INTO bookings(id,name,phone,service,notes,status,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)',
    [id,name,phone,service,notes || '', 'Received', now]);
  res.status(201).json({ id, name, phone, service, status:'Received', created_at: now });
});

// PUBLIC: get booking by id
app.get('/api/bookings/:id', async (req,res)=>{
  const row = (await pool.query('SELECT * FROM bookings WHERE id=$1', [req.params.id])).rows[0];
  if(!row) return res.status(404).json({ error:'Not found' });
  res.json(row);
});

// ADMIN: login
app.post('/api/admin/login', async (req,res)=>{
  const { username, password } = req.body;
  const r = await pool.query('SELECT * FROM admins WHERE username=$1', [username]);
  const row = r.rows[0];
  if(!row) return res.status(401).json({error:'Invalid'});
  if(!bcrypt.compareSync(password, row.password_hash)) return res.status(401).json({error:'Invalid'});
  const token = jwt.sign({ id: row.id, username: row.username }, SECRET, { expiresIn: '8h' });
  res.json({ token });
});

function auth(req,res,next){
  const h = req.headers.authorization;
  if(!h) return res.status(401).json({error:'No token'});
  const token = h.split(' ')[1];
  try{
    req.user = jwt.verify(token, SECRET);
    next();
  }catch(e){ res.status(401).json({error:'Invalid token'}); }
}

// ADMIN: list bookings
app.get('/api/admin/bookings', auth, async (req,res)=>{
  const rows = (await pool.query('SELECT * FROM bookings ORDER BY created_at DESC')).rows;
  res.json(rows);
});

// ADMIN: update booking status
app.patch('/api/admin/bookings/:id', auth, async (req,res)=>{
  const { status } = req.body;
  await pool.query('UPDATE bookings SET status=$1 WHERE id=$2', [status, req.params.id]);
  const row = (await pool.query('SELECT * FROM bookings WHERE id=$1', [req.params.id])).rows[0];
  res.json(row);
});

// INVENTORY endpoints
app.get('/api/admin/inventory', auth, async (req,res)=>{
  const rows = (await pool.query('SELECT * FROM inventory')).rows;
  res.json(rows);
});
app.post('/api/admin/inventory', auth, async (req,res)=>{
  const { part_name, sku, qty, purchase_price, sell_price } = req.body;
  await pool.query('INSERT INTO inventory (part_name,sku,qty,purchase_price,sell_price) VALUES ($1,$2,$3,$4,$5)',
    [part_name, sku, qty||0, purchase_price||0, sell_price||0]);
  res.json({ ok: true });
});

// INVOICES: generate PDF
app.post('/api/admin/invoices', auth, async (req,res)=>{
  const { booking_id, items, gst_percent } = req.body;
  const booking = (await pool.query('SELECT * FROM bookings WHERE id=$1', [booking_id])).rows[0];
  if(!booking) return res.status(404).json({error:'Booking not found'});
  const invoiceNo = `INV-${booking_id}-${Date.now()}`;
  const filepath = await createInvoicePDF({
    invoiceNo,
    billingTo: { name: booking.name, phone: booking.phone },
    items,
    gstPercent: gst_percent || 18,
    outputDir: './uploads'
  });
  await pool.query('INSERT INTO invoices(booking_id,pdf_path) VALUES($1,$2)', [booking_id, filepath]);
  res.json({ ok: true, path: filepath });
});

// RAZORPAY: create order
app.post('/api/admin/payments/razorpay/order', auth, async (req,res)=>{
  const { amount, currency='INR', receipt } = req.body;
  try {
    const order = await razorpay.orders.create({ amount, currency, receipt: receipt || `rcpt_${Date.now()}`, payment_capture: 1 });
    res.json(order);
  } catch(err){ res.status(500).json({ error: err.message }); }
});

// RAZORPAY: verify
const crypto = require('crypto');
app.post('/api/admin/payments/razorpay/verify', auth, async (req,res)=>{
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
  const key_secret = process.env.RAZORPAY_KEY_SECRET || '';
  const generated_signature = crypto.createHmac('sha256', key_secret).update(razorpay_order_id + "|" + razorpay_payment_id).digest('hex');
  if (generated_signature === razorpay_signature) {
    res.json({ ok: true });
  } else {
    res.status(400).json({ error: 'Invalid signature' });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Server listening on', PORT));
