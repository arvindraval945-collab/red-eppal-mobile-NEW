const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const moment = require('moment');

function createInvoicePDF({ invoiceNo, billingTo, items, gstPercent=18, outputDir='./uploads' }) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });
    const filename = `invoice_${invoiceNo}_${Date.now()}.pdf`;
    const filepath = path.join(outputDir, filename);

    const doc = new PDFDocument({ size: 'A4', margin: 50 });
    const stream = fs.createWriteStream(filepath);
    doc.pipe(stream);

    // Header
    doc.fontSize(20).text('Red Eppal Mobile', { align: 'left' });
    doc.fontSize(10).text('Near XYZ, Your City', { align: 'left' });
    doc.moveDown();

    // Invoice meta
    doc.fontSize(12).text(`Invoice No: ${invoiceNo}`, { align: 'right' });
    doc.text(`Date: ${moment().format('YYYY-MM-DD')}`, { align: 'right' });
    doc.moveDown();

    // Billing
    doc.fontSize(12).text('Bill To:', { underline: true });
    doc.fontSize(10).text(billingTo.name || '');
    if (billingTo.phone) doc.text('Phone: ' + billingTo.phone);
    doc.moveDown();

    // Table header
    doc.font('Helvetica-Bold').text('Description', 50, doc.y);
    doc.text('Qty', 350, doc.y);
    doc.text('Rate', 420, doc.y);
    doc.text('Amount', 500, doc.y);
    doc.moveDown();
    doc.font('Helvetica');

    let subtotal = 0;
    items.forEach(it => {
      const amount = (it.qty || 1) * (it.rate || 0);
      subtotal += amount;
      doc.text(it.description, 50, doc.y);
      doc.text(String(it.qty || 1), 350, doc.y);
      doc.text(String((it.rate||0).toFixed(2)), 420, doc.y);
      doc.text(String(amount.toFixed(2)), 500, doc.y);
      doc.moveDown();
    });

    const gstAmount = subtotal * (gstPercent / 100);
    const total = subtotal + gstAmount;

    doc.moveDown();
    doc.text(`Subtotal: ${subtotal.toFixed(2)}`, { align: 'right' });
    doc.text(`GST (${gstPercent}%): ${gstAmount.toFixed(2)}`, { align: 'right' });
    doc.font('Helvetica-Bold').text(`Total: ${total.toFixed(2)}`, { align: 'right' });

    doc.moveDown(2);
    doc.fontSize(10).text('Thank you for your business!', { align: 'center' });

    doc.end();
    stream.on('finish', () => resolve(filepath));
    stream.on('error', reject);
  });
}

module.exports = createInvoicePDF;
