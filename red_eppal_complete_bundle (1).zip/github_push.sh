#!/bin/bash
# Example script to create a GitHub repo using gh CLI and push local code.
# Requires GitHub CLI (gh) installed and authenticated.
REPO_NAME="red-eppal-mobile"
git init
git add .
git commit -m "Initial commit - Red Eppal Mobile complete bundle"
gh repo create $REPO_NAME --public --source=. --remote=origin --push
