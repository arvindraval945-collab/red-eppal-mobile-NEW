import 'package:flutter/material.dart';
import 'pages/splash.dart';
void main() => runApp(const RedEppalApp());
class RedEppalApp extends StatelessWidget {
  const RedEppalApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Red Eppal Mobile',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.red),
      home: const SplashPage(),
    );
  }
}
