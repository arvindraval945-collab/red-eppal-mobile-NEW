import 'package:flutter/material.dart';
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text("Settings")),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
      SwitchListTile(value: true, onChanged: (_) {}, title: const Text("Notifications")),
      ListTile(title: const Text("Language"), subtitle: const Text("Hindi / English"))
    ])),
  );
}
