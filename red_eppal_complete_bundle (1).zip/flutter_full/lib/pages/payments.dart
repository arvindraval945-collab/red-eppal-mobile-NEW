import 'package:flutter/material.dart';
class PaymentsPage extends StatelessWidget {
  const PaymentsPage({super.key});
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text("Payments")),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
      const Text("Payment options: UPI, Cash, Card, Razorpay"),
      ElevatedButton(onPressed: (){}, child: const Text("Pay ₹100"))
    ])),
  );
}
