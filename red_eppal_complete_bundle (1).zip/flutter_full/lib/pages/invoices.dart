import 'package:flutter/material.dart';
class InvoicesPage extends StatelessWidget {
  const InvoicesPage({super.key});
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text("Invoices")),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
      const Text("Generated invoices will show here"),
      ListTile(title: Text("INV-12345"), trailing: Text("Download"))
    ])),
  );
}
