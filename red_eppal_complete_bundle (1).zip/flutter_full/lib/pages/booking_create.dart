import 'package:flutter/material.dart';
import '../services/api.dart';
class BookingCreatePage extends StatefulWidget { const BookingCreatePage({super.key}); @override State<BookingCreatePage> createState()=>_BookingCreatePageState(); }
class _BookingCreatePageState extends State<BookingCreatePage>{
  final name=TextEditingController();
  final phone=TextEditingController();
  String service="Screen Replacement";
  final notes=TextEditingController();
  final services=["Screen Replacement","Battery Replacement","Charging/Port","Software Update","Water Damage"];
  bool loading=false;
  submit() async {
    if(name.text.isEmpty || phone.text.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Enter name & phone"))); return; }
    setState(()=>loading=true);
    try{
      final res = await Api.createBooking(name.text, phone.text, service, notes.text);
      setState(()=>loading=false);
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Booking submitted")));
    } catch(e){
      setState(()=>loading=false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    }
  }
  @override Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text("Book Repair")),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: "Name")),
        TextField(controller: phone, decoration: const InputDecoration(labelText: "Phone")),
        const SizedBox(height:10),
        DropdownButtonFormField(value: service, items: services.map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(), onChanged: (v)=>setState(()=>service=v!)),
        const SizedBox(height:10),
        TextField(controller: notes, decoration: const InputDecoration(labelText: "Notes / Model")),
        const SizedBox(height:18),
        loading? const CircularProgressIndicator() : ElevatedButton(onPressed: submit, child: const Text("Submit"))
      ]),
    ),
  );
}
