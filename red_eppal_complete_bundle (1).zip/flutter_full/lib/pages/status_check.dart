import 'package:flutter/material.dart';
import '../services/api.dart';
import 'booking_detail.dart';
class StatusCheckPage extends StatefulWidget { const StatusCheckPage({super.key}); @override State<StatusCheckPage> createState()=>_StatusCheckPageState(); }
class _StatusCheckPageState extends State<StatusCheckPage>{
  final id=TextEditingController();
  Map? data; bool loading=false;
  check() async {
    if(id.text.isEmpty) return;
    setState(()=>loading=true);
    try{
      data = await Api.getBooking(id.text);
    } catch(e){ ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Not found"))); }
    setState(()=>loading=false);
  }
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text("Check Status")),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
      TextField(controller: id, decoration: const InputDecoration(labelText: "Booking ID")),
      const SizedBox(height:8),
      ElevatedButton(onPressed: check, child: const Text("Check")),
      const SizedBox(height:12),
      if(loading) const CircularProgressIndicator(),
      if(data!=null) ListTile(title: Text("Status: ${data!['status']}"), subtitle: Text("Service: ${data!['service']}"))
    ])),
  );
}
