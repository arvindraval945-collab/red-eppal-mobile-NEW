import 'package:flutter/material.dart';
import 'booking_create.dart';
import 'bookings_list.dart';
import 'status_check.dart';
import 'profile.dart';
import 'inventory.dart';
import 'invoices.dart';
import 'payments.dart';
import 'settings.dart';
import 'about.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: const Text("Red Eppal Mobile"), backgroundColor: Colors.red),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: 2,
          childAspectRatio: 3/2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: [
            _tile(context, "Book Repair", Icons.build, BookingCreatePage()),
            _tile(context, "My Bookings", Icons.list_alt, BookingsListPage()),
            _tile(context, "Check Status", Icons.track_changes, StatusCheckPage()),
            _tile(context, "Inventory", Icons.precision_manufacturing, InventoryPage()),
            _tile(context, "Invoices", Icons.receipt_long, InvoicesPage()),
            _tile(context, "Payments", Icons.payment, PaymentsPage()),
            _tile(context, "Profile", Icons.person, ProfilePage()),
            _tile(context, "Settings", Icons.settings, SettingsPage()),
            _tile(context, "About", Icons.info, AboutPage()),
          ],
        ),
      ),
    );
  }

  Widget _tile(BuildContext c, String title, IconData icon, Widget page){
    return Card(
      child: InkWell(
        onTap: ()=> Navigator.push(c, MaterialPageRoute(builder: (_)=>page)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size:36, color: Colors.red),
            const SizedBox(height:8),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold))
          ]),
        ),
      ),
    );
  }
}
