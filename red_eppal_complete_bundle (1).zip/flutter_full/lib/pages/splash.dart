import 'package:flutter/material.dart';
import 'home.dart';
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override State<SplashPage> createState() => _SplashPageState();
}
class _SplashPageState extends State<SplashPage>{
  @override void initState(){
    super.initState();
    Future.delayed(const Duration(milliseconds:900), (){
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage()));
    });
  }
  @override Widget build(BuildContext c) => Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: const [
    Text("RED EPPAL", style: TextStyle(fontSize:32,fontWeight:FontWeight.bold,color:Colors.red)),
    SizedBox(height:8),
    Text("Mobile Repairing", style: TextStyle(fontSize:16))
  ])));
}
