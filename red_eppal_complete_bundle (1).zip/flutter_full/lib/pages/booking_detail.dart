import 'package:flutter/material.dart';
class BookingDetailPage extends StatelessWidget {
  final Map data;
  const BookingDetailPage({super.key, required this.data});
  @override Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text("Booking Detail")),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      Text("ID: ${data['id']}", style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height:8),
      Text("Name: ${data['name']}"),
      Text("Phone: ${data['phone']}"),
      Text("Service: ${data['service']}"),
      const SizedBox(height:8),
      Text("Status: ${data['status']}")
    ])),
  );
}
