import 'package:flutter/material.dart';
class InventoryPage extends StatelessWidget {
  const InventoryPage({super.key});
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text("Inventory")),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
      const Text("Parts & stock (admin only) - demo"),
      ListTile(title: Text("Screen - Samsung S10"), trailing: Text("2 pcs")),
      ListTile(title: Text("Battery - Xiaomi"), trailing: Text("5 pcs")),
    ])),
  );
}
