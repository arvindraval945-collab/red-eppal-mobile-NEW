import 'package:flutter/material.dart';
import '../services/api.dart';
class BookingsListPage extends StatefulWidget { const BookingsListPage({super.key}); @override State<BookingsListPage> createState()=>_BookingsListPageState(); }
class _BookingsListPageState extends State<BookingsListPage>{
  List bookings = [];
  bool loading=true;
  @override void initState(){ super.initState(); fetch(); }
  fetch() async { setState(()=>loading=true); bookings = await Api.getAllBookings(); setState(()=>loading=false); }
  @override Widget build(BuildContext c)=> Scaffold(
    appBar: AppBar(title: const Text("My Bookings")),
    body: loading? const Center(child:CircularProgressIndicator()) : ListView.builder(itemCount: bookings.length, itemBuilder: (i){
      final b = bookings[i];
      return ListTile(title: Text(b['name'] ?? ''), subtitle: Text("${b['service']} — ${b['status']}"), trailing: Text(b['id']));
    }),
  );
}
