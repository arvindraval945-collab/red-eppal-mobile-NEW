import 'package:flutter/material.dart';
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text("About")),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
      const Text("Red Eppal Mobile — Trusted mobile repair shop."),
      const SizedBox(height:8),
      const Text("Contact: +91 98XXXXXXXX")
    ])),
  );
}
