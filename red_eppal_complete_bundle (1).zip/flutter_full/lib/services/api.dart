import 'dart:convert';
import 'package:http/http.dart' as http;
class Api {
  static const base = "http://localhost:4000/api";
  static Future<Map> createBooking(String name, String phone, String service, String notes) async {
    final url = Uri.parse('$base/bookings');
    final res = await http.post(url, body: {'name': name, 'phone': phone, 'service': service, 'notes': notes});
    return jsonDecode(res.body) as Map;
  }
  static Future<List> getAllBookings() async {
    final url = Uri.parse('$base/admin/bookings');
    final res = await http.get(url);
    if (res.statusCode==200) return List.from(jsonDecode(res.body));
    return [];
  }
  static Future<Map> getBooking(String id) async {
    final url = Uri.parse('$base/bookings/$id');
    final res = await http.get(url);
    return jsonDecode(res.body) as Map;
  }
}
