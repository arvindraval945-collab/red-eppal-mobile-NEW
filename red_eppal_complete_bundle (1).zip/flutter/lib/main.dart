import 'package:flutter/material.dart';
void main() => runApp(const RedEppalApp());
class RedEppalApp extends StatelessWidget {
  const RedEppalApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Red Eppal Mobile',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.red),
      home: Scaffold(appBar: AppBar(title: const Text('Red Eppal Mobile')), body: const Center(child: Text('Flutter app starter — replace with provided files'))),
    );
  }
}
