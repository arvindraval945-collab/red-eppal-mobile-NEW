import axios from 'axios';
const API = axios.create({ baseURL: 'http://localhost:4000/api' });

export async function login(username,password){
  const res = await API.post('/admin/login',{ username, password });
  return res.data;
}

export async function adminGetBookings(token){
  const res = await API.get('/admin/bookings', { headers: { Authorization: `Bearer ${token}` }});
  return res.data;
}

export async function adminUpdateBooking(token,id,status){
  const res = await API.patch(`/admin/bookings/${id}`, { status }, { headers: { Authorization: `Bearer ${token}` }});
  return res.data;
}
