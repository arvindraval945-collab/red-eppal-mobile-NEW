import React, { useState } from 'react';
import Login from './pages/Login';
import Bookings from './pages/Bookings';

export default function App(){
  const [token, setToken] = useState(localStorage.getItem('token'));
  const onLogin = (t) => { localStorage.setItem('token', t); setToken(t); };
  return token ? <Bookings token={token}/> : <Login onLogin={onLogin}/>;
}
