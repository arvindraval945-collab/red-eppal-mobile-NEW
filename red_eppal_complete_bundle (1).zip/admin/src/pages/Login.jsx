import React, { useState } from 'react';
import { login } from '../api';

export default function Login({ onLogin }) {
  const [u,setU]=useState(''); const [p,setP]=useState('');
  const submit = async ()=>{ const r = await login(u,p); onLogin(r.token); };
  return (
    <div style={{padding:20}}>
      <h2>Admin Login</h2>
      <input placeholder="username" value={u} onChange={e=>setU(e.target.value)}/><br/>
      <input placeholder="password" value={p} onChange={e=>setP(e.target.value)} type="password"/><br/>
      <button onClick={submit}>Login</button>
    </div>
  );
}
