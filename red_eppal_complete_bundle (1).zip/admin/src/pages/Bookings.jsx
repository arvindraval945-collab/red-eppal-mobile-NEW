import React, { useEffect, useState } from 'react';
import { adminGetBookings, adminUpdateBooking } from '../api';

export default function Bookings({ token }) {
  const [list, setList] = useState([]);
  useEffect(()=>{ adminGetBookings(token).then(setList); },[]);
  const update = async (id, status) => {
    await adminUpdateBooking(token,id,status);
    setList(await adminGetBookings(token));
  };
  return (
    <div style={{padding:20}}>
      <h3>Bookings</h3>
      {list.map(b=>(
        <div key={b.id} style={{border:'1px solid #ddd',padding:10,marginBottom:8}}>
          <div><b>{b.name}</b> — {b.service} — <i>{b.status}</i></div>
          <div>Phone: {b.phone} | ID: {b.id}</div>
          <button onClick={()=>update(b.id,'Diagnosed')}>Diagnosed</button>
          <button onClick={()=>update(b.id,'Repairing')}>Repairing</button>
          <button onClick={()=>update(b.id,'Ready')}>Ready</button>
        </div>
      ))}
    </div>
  );
}
