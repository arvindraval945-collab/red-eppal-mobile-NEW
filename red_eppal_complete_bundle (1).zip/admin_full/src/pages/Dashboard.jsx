import React, { useState } from 'react';
import Bookings from './Bookings';
import Inventory from './Inventory';
import Invoices from './Invoices';
import Settings from './Settings';

export default function Dashboard({ token }){
  const [view,setView]=useState('bookings');
  const logout=()=>{ localStorage.removeItem('token'); window.location.reload(); };
  return <div>
    <div className="header"><div style={{fontWeight:700}}>Red Eppal Admin</div><div style={{marginLeft:'auto'}}><button className="btn" onClick={logout}>Logout</button></div></div>
    <div className="container grid">
      <div className="sidebar card">
        <div className="list-item" onClick={()=>setView('bookings')}>Bookings</div>
        <div className="list-item" onClick={()=>setView('inventory')}>Inventory</div>
        <div className="list-item" onClick={()=>setView('invoices')}>Invoices</div>
        <div className="list-item" onClick={()=>setView('settings')}>Settings</div>
      </div>
      <div>
        <div className="card">
          {view==='bookings' && <Bookings token={token}/>}
          {view==='inventory' && <Inventory token={token}/>}
          {view==='invoices' && <Invoices token={token}/>}
          {view==='settings' && <Settings token={token}/>}
        </div>
      </div>
    </div>
  </div>
}
