import React, { useEffect, useState } from 'react';
import { adminGetBookings, adminUpdateBooking } from '../api';
export default function Bookings({ token }){
  const [list,setList]=useState([]);
  useEffect(()=>{ adminGetBookings(token).then(setList).catch(()=>setList([])); },[]);
  const update=async(id,status)=>{ await adminUpdateBooking(token,id,status); setList(await adminGetBookings(token)); };
  return <div>
    <h3>Bookings</h3>
    {list.map(b=> <div key={b.id} style={{borderBottom:'1px solid #eee',padding:'8px 0'}}><div><b>{b.name}</b> — {b.service} — <i>{b.status}</i></div><div>Phone: {b.phone} | ID: {b.id}</div><div style={{marginTop:6}}><button onClick={()=>update(b.id,'Diagnosed')} className="btn">Diagnosed</button>&nbsp;<button onClick={()=>update(b.id,'Repairing')}>Repairing</button>&nbsp;<button onClick={()=>update(b.id,'Ready')}>Ready</button></div></div>)}
  </div>;
}
