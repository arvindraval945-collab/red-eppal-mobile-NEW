import React from 'react';
export default function Inventory(){ return <div><h3>Inventory</h3><p>Manage spare parts here.</p></div>; }
