import React, { useState } from 'react';
import { login } from '../api';
export default function Login({ onLogin }){
  const [u,setU]=useState('admin'); const [p,setP]=useState('admin123');
  const submit=async()=>{ try{ const r=await login(u,p); onLogin(r.token);}catch(e){ alert('Login failed'); } };
  return <div className="container"><div className="card" style={{maxWidth:420,margin:'40px auto'}}><h2>Admin Login</h2><input placeholder="username" value={u} onChange={e=>setU(e.target.value)}/><br/><input placeholder="password" value={p} onChange={e=>setP(e.target.value)} type="password"/><br/><button className="btn" onClick={submit}>Login</button></div></div>;
}
