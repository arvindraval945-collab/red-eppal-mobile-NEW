import React from 'react';
export default function Invoices(){ return <div><h3>Invoices</h3><p>Generate / download invoices.</p></div>; }
