import React from 'react';
export default function Settings(){ return <div><h3>Settings</h3><p>Application settings and keys (JWT, Razorpay).</p></div>; }
